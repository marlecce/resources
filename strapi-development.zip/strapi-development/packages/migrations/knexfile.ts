const config = {
  development: {
    client: 'postgresql',
    connection: {
      host: 'localhost',
      user: 'devel',
      password: 'devel',
      database: 'strapi_devel',
    },
    migrations: {
      tableName: 'knex_migrations',
      directory: './data',
    },
    seeds: {
      directory: './seeds',
    },
  },
};

export default config;
