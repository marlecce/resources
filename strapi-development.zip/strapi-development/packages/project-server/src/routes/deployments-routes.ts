import Koa from 'koa';
import Router from 'koa-router';
import { constants } from 'http2';

import {
  fetchDeployments,
  FetchDeploymentsResult,
} from '../services/fetch-deployments';
import {
  DeploymentNotFoundError,
  fetchDeploymentById,
} from '../services/fetch-deployment';
import { deleteDeploymentById } from '../services/delete-deployment';
import { Deployment, DeploymentStatus } from '../models/Deployment';
import {
  generateRandomUrl,
  isFirstProjectDeployment,
  updateProjectUrl,
} from '../services/utils';

const router = new Router();

router.get('/', async (ctx: Koa.Context) => {
  try {
    const page = ctx.query.page ? parseInt(ctx.query.page as string, 10) : 1;
    const pageSize = 8;

    const result: FetchDeploymentsResult = await fetchDeployments(
      page,
      pageSize
    );

    ctx.body = result;
  } catch (error) {
    console.error('Error retrieving deployments:', error);
    ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
    ctx.body = { error: 'An error occurred while retrieving deployments' };
  }
});

router.get('/:id', async (ctx: Koa.Context) => {
  try {
    const deploymentId = parseInt(ctx.params.id as string, 10);

    const deployment = await fetchDeploymentById(deploymentId);

    ctx.body = deployment;
  } catch (error) {
    console.error('Error retrieving project:', error);

    if (error instanceof DeploymentNotFoundError) {
      ctx.status = constants.HTTP_STATUS_NOT_FOUND;
      ctx.body = { error: 'Deployment not found' };
    } else {
      ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
      ctx.body = { error: 'An error occurred while retrieving the deployment' };
    }
  }
});

router.delete('/:id', async (ctx: Koa.Context) => {
  try {
    const deploymentId = parseInt(ctx.params.id as string, 10);

    await deleteDeploymentById(deploymentId);

    ctx.status = constants.HTTP_STATUS_NO_CONTENT;
  } catch (error) {
    console.error('Error deleting deployment:', error);

    if ((error as Error).message.includes('not found')) {
      ctx.status = constants.HTTP_STATUS_NOT_FOUND;
      ctx.body = { error: 'Deployment not found' };
    } else {
      ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
      ctx.body = { error: 'An error occurred while deleting the deployment' };
    }
  }
});

router.post('/webhook', async (ctx: Koa.Context) => {
  try {
    const authorizationHeader = ctx.request.headers.authorization_deploy;

    const {
      deploymentId,
      status,
    }: { deploymentId: number; status: DeploymentStatus } = ctx.request
      .body as {
      deploymentId: number;
      status: DeploymentStatus;
    };

    const deployment: Deployment = await fetchDeploymentById(deploymentId);

    const isFirstDeployment: boolean = await isFirstProjectDeployment(
      deployment.project_id
    );

    const isAuthorized: boolean =
      status === DeploymentStatus.Done &&
      isFirstDeployment &&
      authorizationHeader === deployment.app_secret;

    if (isAuthorized) {
      const randomUrl = generateRandomUrl();

      await updateProjectUrl(deployment.project_id, randomUrl);
      ctx.status = constants.HTTP_STATUS_OK;
      ctx.body = 'Webhook received and processed successfully';
    } else {
      ctx.status = constants.HTTP_STATUS_UNAUTHORIZED;
      ctx.body = 'Webhook request is not authorized';
    }
  } catch (error) {
    console.error('Error handling webhook:', error);

    ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
    ctx.body = {
      error: 'An error occurred while handling the webhook',
    };
  }
});

export default router;
