import projectsData from './data/projects.json';
import usersData from './data/users.json';
import { Knex } from 'knex';

async function seedProjects(knex: Knex) {
  const projectInsertData = projectsData.map((project) => {
    const { id, user_id, ...projectData } = project;
    return {
      ...projectData,
      owner_id: user_id,
    };
  });

  await knex('projects').insert(projectInsertData);
}

export async function seed (knex: Knex) {
  try {
    await knex.transaction(async (trx) => {
      // Delete existing data from tables
      await trx('projects').del();
      await trx('users').del();

      // Seed users
      await trx('users').insert(usersData);

      // Seed projects
      await seedProjects(trx);
    });
  } catch (error) {
    console.error('Error occurred during seeding:', error);
  }
};
