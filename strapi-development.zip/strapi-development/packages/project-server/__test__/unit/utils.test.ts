import knexInstance from '../../src/database';
import {
  DEPLOYMENT_TABLENAME,
  Deployment,
  DeploymentStatus,
} from '../../src/models/Deployment';
import { PROJECT_TABLENAME, Project } from '../../src/models/Project';
import {
  isFirstProjectDeployment,
  updateProjectUrl,
  generateRandomUrl,
  calculateOffset,
} from '../../src/services/utils';

describe('utils test suite', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  const mockDeployments: Deployment[] = [
    {
      id: 1,
      project_id: 1,
      deployed_in: 1,
      status: DeploymentStatus.Done,
      app_secret: 'abc123',
      created_at: new Date('2022-01-01'),
    },
    {
      id: 3,
      project_id: 2,
      deployed_in: 3,
      status: DeploymentStatus.Done,
      app_secret: 'ghi789',
      created_at: new Date('2022-01-03'),
    },
    {
      id: 4,
      project_id: 2,
      deployed_in: 4,
      status: DeploymentStatus.Done,
      app_secret: 'jkl012',
      created_at: new Date('2022-01-04'),
    },
    {
      id: 5,
      project_id: 3,
      deployed_in: 5,
      status: DeploymentStatus.Done,
      app_secret: 'mno345',
      created_at: new Date('2022-01-05'),
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
    await knexInstance(DEPLOYMENT_TABLENAME).insert(mockDeployments);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
  });

  it('should return true if it is the first deployment of the project', async () => {
    const projectId = 1;

    const result = await isFirstProjectDeployment(projectId);

    expect(result).toBe(true);
  });

  it('should return false if it is not the first deployment of the project', async () => {
    const projectId = 2;

    const result = await isFirstProjectDeployment(projectId);

    expect(result).toBe(false);
  });

  it('should update the project URL successfully', async () => {
    const projectId = 1;
    const newUrl = 'https://updated-url.com';

    await updateProjectUrl(projectId, newUrl);

    const updatedProject = await knexInstance(PROJECT_TABLENAME)
      .select('url')
      .where({ id: projectId })
      .first();

    expect(updatedProject.url).toBe(newUrl);
  });

  it('should throw an error if project update fails', async () => {
    const projectId = 999;
    const newUrl = 'https://updated-url.com';

    await expect(updateProjectUrl(projectId, newUrl)).rejects.toThrowError(
      'An error occurred while updating project URL'
    );
  });

  it('should generate a random URL with the specified length', () => {
    const url = generateRandomUrl();

    expect(url.length).toBe(10);
  });

  it('should generate a different URL each time', () => {
    const url1 = generateRandomUrl();
    const url2 = generateRandomUrl();

    expect(url1).not.toBe(url2);
  });

  it('should calculate the correct offset', () => {
    const testCases = [
      { page: 1, pageSize: 8, expectedOffset: 0 },
      { page: 2, pageSize: 10, expectedOffset: 10 },
      { page: 3, pageSize: 20, expectedOffset: 40 },
      { page: 4, pageSize: 5, expectedOffset: 15 },
    ];

    testCases.forEach(({ page, pageSize, expectedOffset }) => {
      const offset = calculateOffset(page, pageSize);
      expect(offset).toBe(expectedOffset);
    });
  });
});
