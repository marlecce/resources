import knexInstance from '../../../src/database';
import {
  DeploymentStatus,
  Deployment,
  DEPLOYMENT_TABLENAME,
} from '../../../src/models/Deployment';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import * as fetchDeploymentModule from '../../../src/services/fetch-deployment';

describe('fetchDeployment test suite', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  const mockDeployments: Deployment[] = [
    {
      id: 1,
      project_id: 1,
      deployed_in: 1,
      status: DeploymentStatus.Done,
      app_secret: 'abc123',
      created_at: new Date('2022-01-01'),
    },
    {
      id: 2,
      project_id: 1,
      deployed_in: 2,
      status: DeploymentStatus.Done,
      app_secret: 'def456',
      created_at: new Date('2022-01-02'),
    },
    {
      id: 3,
      project_id: 2,
      deployed_in: 3,
      status: DeploymentStatus.Done,
      app_secret: 'ghi789',
      created_at: new Date('2022-01-03'),
    },
    {
      id: 4,
      project_id: 2,
      deployed_in: 4,
      status: DeploymentStatus.Done,
      app_secret: 'jkl012',
      created_at: new Date('2022-01-04'),
    },
    {
      id: 5,
      project_id: 3,
      deployed_in: 5,
      status: DeploymentStatus.Done,
      app_secret: 'mno345',
      created_at: new Date('2022-01-05'),
    },
    {
      id: 6,
      project_id: 3,
      deployed_in: 6,
      status: DeploymentStatus.Done,
      app_secret: 'pqr678',
      created_at: new Date('2022-01-06'),
    },
    {
      id: 7,
      project_id: 3,
      deployed_in: 7,
      status: DeploymentStatus.Done,
      app_secret: 'stu901',
      created_at: new Date('2022-01-07'),
    },
    {
      id: 8,
      project_id: 3,
      deployed_in: 8,
      status: DeploymentStatus.Done,
      app_secret: 'vwx234',
      created_at: new Date('2022-01-08'),
    },
    {
      id: 9,
      project_id: 3,
      deployed_in: 9,
      status: DeploymentStatus.Done,
      app_secret: 'yz0123',
      created_at: new Date('2022-01-09'),
    },
    {
      id: 10,
      project_id: 3,
      deployed_in: 10,
      status: DeploymentStatus.Done,
      app_secret: '456789',
      created_at: new Date('2022-01-10'),
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
    await knexInstance(DEPLOYMENT_TABLENAME).insert(mockDeployments);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
  });

  it('should fetch a deployment by ID', async () => {
    const deploymentId = 2;

    const deployment = await fetchDeploymentModule.fetchDeploymentById(
      deploymentId
    );

    expect(deployment.id).toEqual(mockDeployments[1].id);
    expect(deployment.project_id).toEqual(mockDeployments[1].project_id);
    expect(deployment.deployed_in).toEqual(mockDeployments[1].deployed_in);
    expect(deployment.status).toEqual(mockDeployments[1].status);
    expect(deployment.app_secret).toEqual(mockDeployments[1].app_secret);
    expect(deployment.created_at).toEqual(mockDeployments[1].created_at);
  });

  it('should return a deployment not found error if deployment id is not found', async () => {
    const deploymentId = 100;

    await expect(
      fetchDeploymentModule.fetchDeploymentById(deploymentId)
    ).rejects.toThrowError(
      new fetchDeploymentModule.DeploymentNotFoundError(deploymentId)
    );
  });

  it('should handle errors and propagate them', async () => {
    const deploymentId = 1;
    const error = new Error('Error fetching deployment with ID 1');

    jest
      .spyOn(fetchDeploymentModule, 'fetchDeploymentById')
      .mockRejectedValue(error);

    await expect(
      fetchDeploymentModule.fetchDeploymentById(deploymentId)
    ).rejects.toThrowError(error);

    jest.restoreAllMocks();
  });
});
