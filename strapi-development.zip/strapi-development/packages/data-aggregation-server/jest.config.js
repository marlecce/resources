/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  collectCoverage: true,
  collectCoverageFrom: [
    'packages/**/src/**/*.{ts,tsx}',
    '!packages/**/src/**/*.test.{ts,tsx}',
    '!packages/**/node_modules/',
  ],
  coverageReporters: ['lcov', 'text'],
  coverageDirectory: 'coverage',
};
