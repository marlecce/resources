# My Project

For this project, I set up a monorepo structure using Yarn workspaces to manage multiple packages within a single repository. The monorepo contains three packages: the Migration Service, the Data Aggregation Service, and the Project Server.

- Migration Service: This package handles database migrations using Knex.js. It is responsible for managing the database schema and executing migrations when needed.

- Data Aggregation Service: This package is a server built with Koa.js and is responsible for aggregating data from various sources. It provides an API endpoint to create events and stores them in a PostgreSQL database using Knex.js.

- Project Server: This package is also built with Koa.js and serves as a project management server. It provides API endpoints for managing projects and deployments. It uses a middleware for token validation and includes a data aggregation middleware to send events to the Data Aggregation Service.

## Test-Driven Development (TDD)

During the development of this project, I followed the principles of Test-Driven Development (TDD) to ensure code quality and maintainability. By incorporating TDD into the development process, I aimed to deliver robust and reliable code that meets the specified requirements and maintains high quality throughout the project's lifecycle. 

I used Jest as the testing framework for unit tests, integration tests and end-to-end tests. The tests are organized into separate directories within the "test" directory of each package.

- Unit Tests: Unit tests were written to verify the functionality of individual functions and modules within each package. I used mocks and stubs where needed to isolate dependencies and ensure test reliability.

- Integration tests: Integration testing focuses on verifying the interactions between different components or modules of a system, in particular to verify the interactions between the applications and the database. It ensures that the integrated parts of the application work correctly together and that data flows as expected.

- End-to-End Tests: End-to-end tests were written to simulate real-world scenarios and validate the interaction between different components. Supertest was used to make HTTP requests to the server endpoints and assert the expected responses.

## Code Coverage

Code coverage is a critical aspect of software development, providing insights into the effectiveness of testing efforts and identifying areas that require further attention. In my project, I employed c8, a code coverage tool, to measure and analyze the extent of code covered by tests. By leveraging c8, I aimed to ensure the quality and reliability of my software by identifying untested or under-tested code segments.
By embracing code coverage as an integral part of my development process, I have enhanced the overall reliability and maintainability of my software.

## Linting and Code Formatting

For linting and code formatting, I used ESLint with the recommended configuration along with the Prettier plugin. This ensures consistent code style and helps catch potential errors and code issues.

## Implementation Choices

### Token Validation Middleware

To secure the two server applications, I implemented a middleware to validate the bearer token provided in the request headers. Using the Koa framework, I created a middleware function to extract the bearer token from the request headers. It looks for the Authorization header and checks if it starts with the word "Bearer". If found, it extracts the token value. 
The extracted token is then validated using a predefined token: if the token validation fails or no token is provided, the middleware responds with an HTTP 401 Unauthorized status code. This indicates that the user is not authorized to access the requested resource. If the token validation is successful, the middleware calls the next function to pass control to the next middleware or route handler in the chain.

By implementing this token validation middleware, my project gains the following benefits:

- Security: The middleware ensures that only requests with a valid and authenticated bearer token can proceed further in the application. This helps protect sensitive routes and resources from unauthorized access.

- Reusability: The middleware can be easily reused across multiple routes or endpoints that require token validation. It provides a centralized and consistent mechanism for validating tokens throughout the project.

- Decoupling: The token validation middleware is decoupled from the specific authentication mechanism. It focuses solely on token validation and can be easily integrated with different authentication strategies or services.

### Event Creation Middleware

To create an event for every performed action and send it to the Data Aggregator service, I implemented a middleware that runs after each action is performed. Here are the implementation choices I made for this middleware:

1. Middleware Function: I created a middleware function using the Koa framework. This function takes in the Koa context (ctx) and the next function as parameters.

2. Event Payload: The middleware extracts relevant information from the request and response objects, such as the method, path, request body, query parameters, response status, and response body. It constructs an event payload object containing this information.

3. Event Creation: Using the constructed event payload, the middleware creates an event object with a specified name and the payload. This event represents the performed action and will be sent to the Data Aggregator service.

4. Asynchronous Event Sending: To ensure that the event creation process does not impact the performance of the project service, the middleware sends the event to the Data Aggregator service asynchronously. This is typically done using an asynchronous HTTP request or a message queue: I preferred to follow the first option using "axios" as the library. Considering the pros and cons, I thought that although the message queue had interesting advantages (fault tolerance, decoupling), it would add a significant level of complexity to the project. Since there were no specific requirements regarding reliability, I decided that logging the events would be sufficient to track them even in the event of a network error.

5. Error Handling: The middleware handles any errors that occur during the event creation or sending process. If an error occurs, it is logged or handled appropriately to avoid interrupting the main request flow.

By implementing this event creation middleware, my project gains the following benefits:

- Data Aggregation: The middleware automatically creates events for each performed action, allowing you to aggregate data for product analytics and provide an activity feed to users. This helps in monitoring and analyzing user actions and system behavior.

- Performance Optimization: By sending the event asynchronously, the middleware ensures that the event creation process does not impact the performance of the project service. It separates the event sending task from the main request flow, allowing the service to respond quickly to user requests.

- Modularity: The middleware can be easily added or removed from specific routes or endpoints where event creation is required. This provides flexibility in choosing which actions should generate events and allows for fine-grained control over event generation.

- Centralized Logic: The event creation logic is centralized within the middleware, making it easier to maintain and update. Any changes or enhancements to the event payload or event sending process can be applied in a single location.

- Scalability: The middleware allows for seamless integration with the Data Aggregator service, which can handle the processing and storage of events. This enables scalability by offloading the event handling tasks to a separate service that can be scaled independently.
