import request from 'supertest';
import { constants } from 'http2';

import * as fetchProjectModule from '../../../src/services/fetch-project';
import knexInstance from '../../../src/database';
import app from '../../../src/index';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import { BEARER_TOKEN } from '../../../src/middlewares/token-validation';
import { DEPLOYMENT_TABLENAME } from '../../../src/models/Deployment';

describe('/projects/:id endpoint', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
    {
      id: 4,
      name: 'Project 4',
      url: 'https://project4.com',
      created_at: new Date('2022-04-01'),
      owner_id: 2,
    },
    {
      id: 5,
      name: 'Project 5',
      url: null,
      created_at: new Date('2022-05-01'),
      owner_id: 1,
    },
    {
      id: 6,
      name: 'Project 6',
      url: 'https://project6.com',
      created_at: new Date('2022-06-01'),
      owner_id: 2,
    },
    {
      id: 7,
      name: 'Project 7',
      url: 'https://project7.com',
      created_at: new Date('2022-07-01'),
      owner_id: 1,
    },
    {
      id: 8,
      name: 'Project 8',
      url: null,
      created_at: new Date('2022-08-01'),
      owner_id: 2,
    },
    {
      id: 9,
      name: 'Project 9',
      url: 'https://project9.com',
      created_at: new Date('2022-09-01'),
      owner_id: 1,
    },
    {
      id: 10,
      name: 'Project 10',
      url: 'https://project10.com',
      created_at: new Date('2022-10-01'),
      owner_id: 2,
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should return a project by id', async () => {
    const response = await request(app)
      .get('/api/v1/projects/2')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_OK);

    const projectInResponse = response.body;
    const formattedProject = {
      ...mockProjects[1],
      created_at: mockProjects[1].created_at.toISOString(),
    };

    expect(projectInResponse.id).toEqual(formattedProject.id);
    expect(projectInResponse.name).toEqual(formattedProject.name);
    expect(projectInResponse.owner_id).toEqual(formattedProject.owner_id);
    expect(projectInResponse.url).toEqual(formattedProject.url);
    expect(projectInResponse.created_at).toEqual(formattedProject.created_at);
    expect(projectInResponse.hasLiveDeployment).toBeFalsy;
    expect(projectInResponse.hasOngoingDeployment).toBeFalsy();
  });

  it('should return a project not found error when accessing a non-existent project ID', async () => {
    const response = await request(app)
      .get('/api/v1/projects/99999')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_NOT_FOUND);

    const responseBody = response.body;
    expect(responseBody.error).toBe('Project not found');
  });

  it('should return an internal server error', async () => {
    const error = new Error('Error fetching project with ID 1');

    jest.spyOn(fetchProjectModule, 'fetchProjectById').mockRejectedValue(error);

    const response = await request(app)
      .get('/api/v1/projects/1')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_INTERNAL_SERVER_ERROR);

    const responseBody = response.body;
    expect(responseBody.error).toBe(
      'An error occurred while retrieving the project'
    );

    jest.restoreAllMocks();
  });

  it('should set hasOngoingDeployment to true if project has ongoing deployments', async () => {
    const projectId = 3;

    await knexInstance(DEPLOYMENT_TABLENAME).insert({
      project_id: projectId,
      status: 'pending',
      created_at: new Date(),
      app_secret: 'test-secret',
    });

    const response = await request(app)
      .get(`/api/v1/projects/${projectId}`)
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_OK);

    const projectInResponse = response.body;
    expect(projectInResponse.hasOngoingDeployment).toBeTruthy();
    expect(projectInResponse.hasLiveDeployment).toBeFalsy();
  });

  it('should set hasLiveDeployment to true if project has live deployments', async () => {
    const projectId = 4;

    await knexInstance(DEPLOYMENT_TABLENAME).insert({
      project_id: projectId,
      status: 'done',
      created_at: new Date(),
      app_secret: 'test-secret',
    });

    const response = await request(app)
      .get(`/api/v1/projects/${projectId}`)
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_OK);

    const projectInResponse = response.body;
    expect(projectInResponse.hasLiveDeployment).toBeTruthy();
    expect(projectInResponse.hasOngoingDeployment).toBeFalsy();
  });
});
