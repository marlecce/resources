import Koa from 'koa';
import { constants } from 'http2';

export const BEARER_TOKEN = 'your-bearer-token';

const tokenValidationMiddleware = async (ctx: Koa.Context, next: Koa.Next) => {
  const authorizationHeader = ctx.headers.authorization;

  if (authorizationHeader && authorizationHeader === `Bearer ${BEARER_TOKEN}`) {
    await next();
  } else {
    ctx.status = constants.HTTP_STATUS_UNAUTHORIZED;
    ctx.body = 'Unauthorized';
  }
};

export default tokenValidationMiddleware;
