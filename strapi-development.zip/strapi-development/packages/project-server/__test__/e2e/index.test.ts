import { constants } from 'http2';
import request from 'supertest';

import app from '../../src/index';
import { BEARER_TOKEN } from '../../src/middlewares/token-validation';

describe('Project Server test suite', () => {
  afterAll(async () => {
    app.close();
  });

  test('should return Unauthorized', async () => {
    const response = await request(app).get('/');

    expect(response.status).toBe(constants.HTTP_STATUS_UNAUTHORIZED);
    expect(response.text).toEqual('Unauthorized');
  });

  it('should return "Hello, world!"', async () => {
    const response = await request(app)
      .get('/api/v1')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_OK);
    expect(response.text).toBe('Hello, world!');
  });
});
