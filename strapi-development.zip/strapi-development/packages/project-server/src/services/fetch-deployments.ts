import { DEPLOYMENT_TABLENAME, Deployment } from '../models/Deployment';
import knex from '../database';
import { calculateOffset, fetchTotalItemCount } from './utils';

export interface FetchDeploymentsResult {
  deployments: Deployment[];
  page: number;
  pageSize: number;
  totalCount: number;
}

export async function fetchDeployments(
  page: number,
  pageSize: number
): Promise<FetchDeploymentsResult> {
  try {
    const offset = calculateOffset(page, pageSize);

    const [deployments, totalCount] = await Promise.all([
      fetchDeploymentsWithPagination(offset, pageSize),
      fetchTotalItemCount(DEPLOYMENT_TABLENAME),
    ]);

    return {
      deployments,
      page,
      pageSize,
      totalCount,
    };
  } catch (error) {
    console.error('Error fetching projects:', error);
    throw error;
  }
}

async function fetchDeploymentsWithPagination(
  offset: number,
  pageSize: number
): Promise<Deployment[]> {
  return knex<Deployment>(DEPLOYMENT_TABLENAME).offset(offset).limit(pageSize);
}
