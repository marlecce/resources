import request from 'supertest';
import { constants } from 'http2';

import * as fetchDeploymentModule from '../../../src/services/fetch-deployment';
import knexInstance from '../../../src/database';
import app from '../../../src/index';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import {
  DEPLOYMENT_TABLENAME,
  Deployment,
  DeploymentStatus,
} from '../../../src/models/Deployment';
import { BEARER_TOKEN } from '../../../src/middlewares/token-validation';

describe('get /deployments:id endpoint', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  const mockDeployments: Deployment[] = [
    {
      id: 1,
      project_id: 1,
      deployed_in: 1,
      status: DeploymentStatus.Done,
      app_secret: 'abc123',
      created_at: new Date('2022-01-01'),
    },
    {
      id: 2,
      project_id: 1,
      deployed_in: 2,
      status: DeploymentStatus.Done,
      app_secret: 'def456',
      created_at: new Date('2022-01-02'),
    },
    {
      id: 3,
      project_id: 2,
      deployed_in: 3,
      status: DeploymentStatus.Done,
      app_secret: 'ghi789',
      created_at: new Date('2022-01-03'),
    },
    {
      id: 4,
      project_id: 2,
      deployed_in: 4,
      status: DeploymentStatus.Done,
      app_secret: 'jkl012',
      created_at: new Date('2022-01-04'),
    },
    {
      id: 5,
      project_id: 3,
      deployed_in: 5,
      status: DeploymentStatus.Done,
      app_secret: 'mno345',
      created_at: new Date('2022-01-05'),
    },
    {
      id: 6,
      project_id: 3,
      deployed_in: 6,
      status: DeploymentStatus.Done,
      app_secret: 'pqr678',
      created_at: new Date('2022-01-06'),
    },
    {
      id: 7,
      project_id: 3,
      deployed_in: 7,
      status: DeploymentStatus.Done,
      app_secret: 'stu901',
      created_at: new Date('2022-01-07'),
    },
    {
      id: 8,
      project_id: 3,
      deployed_in: 8,
      status: DeploymentStatus.Done,
      app_secret: 'vwx234',
      created_at: new Date('2022-01-08'),
    },
    {
      id: 9,
      project_id: 3,
      deployed_in: 9,
      status: DeploymentStatus.Done,
      app_secret: 'yz0123',
      created_at: new Date('2022-01-09'),
    },
    {
      id: 10,
      project_id: 3,
      deployed_in: 10,
      status: DeploymentStatus.Done,
      app_secret: '456789',
      created_at: new Date('2022-01-10'),
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
    await knexInstance(DEPLOYMENT_TABLENAME).insert(mockDeployments);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should return a deployment by id', async () => {
    const response = await request(app)
      .get('/api/v1/deployments/2')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_OK);

    const deploymentInResponse = response.body;
    const formattedDeployment = {
      ...mockDeployments[1],
      created_at: mockDeployments[1].created_at.toISOString(),
    };

    expect(deploymentInResponse.id).toEqual(formattedDeployment.id);
    expect(deploymentInResponse.project_id).toEqual(
      formattedDeployment.project_id
    );
    expect(deploymentInResponse.deployed_in).toEqual(
      formattedDeployment.deployed_in
    );
    expect(deploymentInResponse.status).toEqual(formattedDeployment.status);
    expect(deploymentInResponse.app_secret).toEqual(
      formattedDeployment.app_secret
    );
    expect(deploymentInResponse.created_at).toEqual(
      formattedDeployment.created_at
    );
  });

  it('should return a deployment not found error when accessing a non-existent deployment ID', async () => {
    const response = await request(app)
      .get('/api/v1/deployments/99999')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_NOT_FOUND);

    const responseBody = response.body;
    expect(responseBody.error).toBe('Deployment not found');
  });

  it('should return an internal server error', async () => {
    const error = new Error('Error fetching project with ID 1');

    jest
      .spyOn(fetchDeploymentModule, 'fetchDeploymentById')
      .mockRejectedValue(error);

    const response = await request(app)
      .get('/api/v1/deployments/1')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_INTERNAL_SERVER_ERROR);

    const responseBody = response.body;
    expect(responseBody.error).toBe(
      'An error occurred while retrieving the deployment'
    );

    jest.restoreAllMocks();
  });
});
