import { Event, EventPayload } from '../models/Event';
import knex from '../database';

export async function createEvent(
  name: string,
  payload: EventPayload
): Promise<Event> {
  try {
    const event: Omit<Event, 'id'> = {
      name,
      payload,
      created_at: new Date(),
    };

    const [createdEvent] = await knex<Event>('events')
      .insert(event)
      .returning('*');

    return createdEvent;
  } catch (error) {
    console.error(
      `Error creating event ${name}, payload: ${JSON.stringify(payload)}`,
      error
    );
    throw error;
  }
}
