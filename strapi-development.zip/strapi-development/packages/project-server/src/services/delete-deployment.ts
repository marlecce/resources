import knex from '../database';
import { DEPLOYMENT_TABLENAME } from '../models/Deployment';

export async function deleteDeploymentById(
  deploymentId: number
): Promise<void> {
  try {
    const deletedCount = await knex(DEPLOYMENT_TABLENAME)
      .where('id', deploymentId)
      .delete();

    if (deletedCount === 0) {
      throw new Error(`Deployment with ID ${deploymentId} not found`);
    }
  } catch (error) {
    console.error(`Error deleting deployment with ID ${deploymentId}:`, error);
    throw error;
  }
}
