import knexInstance from '../../../src/database';
import {
  DEPLOYMENT_TABLENAME,
  DeploymentStatus,
} from '../../../src/models/Deployment';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import * as createDeploymentModule from '../../../src/services/create-deployment';

describe('create-deployment test suite', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance.destroy();
  });

  it('should create a new deployment', async () => {
    const projectId = 1;
    const status = DeploymentStatus.Pending;
    const appSecret = 'test-secret';

    const deployment = await createDeploymentModule.createDeployment(
      projectId,
      status,
      appSecret
    );

    expect(deployment).toBeDefined();
    expect(deployment.id).toBeDefined();
    expect(deployment.project_id).toBe(projectId);
    expect(deployment.status).toBe(status);
    expect(deployment.app_secret).toBe(appSecret);
    expect(deployment.created_at).toBeDefined();

    const createdDeployment = await knexInstance(DEPLOYMENT_TABLENAME)
      .where('id', deployment.id)
      .first();
    expect(createdDeployment).toEqual(deployment);
  });

  it('should throw an error if project does not exist', async () => {
    const projectId = 999;
    const status = DeploymentStatus.Pending;
    const appSecret = 'test-secret';

    await expect(
      createDeploymentModule.createDeployment(projectId, status, appSecret)
    ).rejects.toThrowError();
  });
});
