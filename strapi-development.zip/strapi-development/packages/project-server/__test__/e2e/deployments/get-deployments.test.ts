import request from 'supertest';
import { constants } from 'http2';

import knexInstance from '../../../src/database';
import app from '../../../src/index';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import {
  DEPLOYMENT_TABLENAME,
  Deployment,
  DeploymentStatus,
} from '../../../src/models/Deployment';
import { BEARER_TOKEN } from '../../../src/middlewares/token-validation';

describe('get /deployments endpoint', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  const mockDeployments: Deployment[] = [
    {
      id: 1,
      project_id: 1,
      deployed_in: 1,
      status: DeploymentStatus.Done,
      app_secret: 'abc123',
      created_at: new Date('2022-01-01'),
    },
    {
      id: 2,
      project_id: 1,
      deployed_in: 2,
      status: DeploymentStatus.Done,
      app_secret: 'def456',
      created_at: new Date('2022-01-02'),
    },
    {
      id: 3,
      project_id: 2,
      deployed_in: 3,
      status: DeploymentStatus.Done,
      app_secret: 'ghi789',
      created_at: new Date('2022-01-03'),
    },
    {
      id: 4,
      project_id: 2,
      deployed_in: 4,
      status: DeploymentStatus.Done,
      app_secret: 'jkl012',
      created_at: new Date('2022-01-04'),
    },
    {
      id: 5,
      project_id: 3,
      deployed_in: 5,
      status: DeploymentStatus.Done,
      app_secret: 'mno345',
      created_at: new Date('2022-01-05'),
    },
    {
      id: 6,
      project_id: 3,
      deployed_in: 6,
      status: DeploymentStatus.Done,
      app_secret: 'pqr678',
      created_at: new Date('2022-01-06'),
    },
    {
      id: 7,
      project_id: 3,
      deployed_in: 7,
      status: DeploymentStatus.Done,
      app_secret: 'stu901',
      created_at: new Date('2022-01-07'),
    },
    {
      id: 8,
      project_id: 3,
      deployed_in: 8,
      status: DeploymentStatus.Done,
      app_secret: 'vwx234',
      created_at: new Date('2022-01-08'),
    },
    {
      id: 9,
      project_id: 3,
      deployed_in: 9,
      status: DeploymentStatus.Done,
      app_secret: 'yz0123',
      created_at: new Date('2022-01-09'),
    },
    {
      id: 10,
      project_id: 3,
      deployed_in: 10,
      status: DeploymentStatus.Done,
      app_secret: '456789',
      created_at: new Date('2022-01-10'),
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
    await knexInstance(DEPLOYMENT_TABLENAME).insert(mockDeployments);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should return a paginated list of deployments', async () => {
    const pageSize = 8;
    const response = await request(app)
      .get('/api/v1/deployments')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_OK);
    expect(response.body).toHaveProperty(DEPLOYMENT_TABLENAME);
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('pageSize');
    expect(response.body).toHaveProperty('totalCount');

    const deploymentsInResponse = response.body.deployments;
    const deploymentsInDatabase = await knexInstance<Project>(
      DEPLOYMENT_TABLENAME
    )
      .select()
      .limit(pageSize);

    const deploymentsInDatabaseFormatted = deploymentsInDatabase.map(
      (deployment) => ({
        ...deployment,
        created_at: deployment.created_at.toISOString(),
      })
    );

    expect(deploymentsInResponse.length).toBe(pageSize);
    expect(deploymentsInResponse).toEqual(deploymentsInDatabaseFormatted);
  });

  it('should return the deployments with the specified page size', async () => {
    const pageSize = 8;
    const response = await request(app)
      .get('/api/v1/deployments')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.body.deployments.length).toBe(pageSize);

    const deploymentsInResponse = response.body.deployments;
    const expectedDeployments = mockDeployments.slice(0, pageSize);

    const expectedDeploymentsFormatted = expectedDeployments.map(
      (deployment) => ({
        ...deployment,
        created_at: deployment.created_at.toISOString(),
      })
    );

    expect(deploymentsInResponse).toEqual(expectedDeploymentsFormatted);
  });

  it('should return the deployments for the specified page', async () => {
    const page = 2;
    const response = await request(app)
      .get('/api/v1/deployments?page=2')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.body.page).toBe(page);

    const deployment9 = response.body.deployments[0];
    const deployment10 = response.body.deployments[1];

    const mockProjectsFormatted = [
      ...mockDeployments.slice(0, 8),
      {
        ...mockDeployments[8],
        created_at: mockDeployments[8].created_at.toISOString(),
      },
      {
        ...mockDeployments[9],
        created_at: mockDeployments[9].created_at.toISOString(),
      },
    ];

    expect(deployment9).toEqual(mockProjectsFormatted[8]);
    expect(deployment10).toEqual(mockProjectsFormatted[9]);
  });

  it('should handle errors and return a 500 status code', async () => {
    const response = await request(app)
      .get('/api/v1/deployments?page=-1')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_INTERNAL_SERVER_ERROR);
    expect(response.body).toEqual({
      error: 'An error occurred while retrieving deployments',
    });
  });
});
