export const DEPLOYMENT_TABLENAME = 'deployments';

export enum DeploymentStatus {
  Pending = 'pending',
  Building = 'building',
  Deploying = 'deploying',
  Failed = 'failed',
  Cancelled = 'cancelled',
  Done = 'done',
}

export interface Deployment {
  id: number;
  project_id: number;
  deployed_in: number | null;
  status: DeploymentStatus;
  app_secret: string;
  created_at: Date;
}
