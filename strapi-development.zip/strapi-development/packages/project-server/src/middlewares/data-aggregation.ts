import axios from 'axios';
import Koa from 'koa';

export const dataAggregationMiddleware = async (
  ctx: Koa.Context,
  next: Koa.Next
) => {
  try {
    // Perform the operation and call the next middleware
    await next();

    const { method, path, request, response } = ctx;

    const eventPayload = {
      method,
      path,
      request: {
        body: request.body,
        params: ctx.params,
        query: request.query,
      },
      response: {
        status: response.status,
        body: response.body,
      },
    };

    const event = {
      name: 'operation',
      payload: eventPayload,
    };

    // Send the event to the Data Aggregator service asynchronously
    axios
      .post('http://localhost:3001/api/v1/events', event, {
        headers: {
          Authorization: 'Bearer your-bearer-token-data-aggregation',
        },
      })
      .catch((error) => {
        console.error('Error sending event to Data Aggregator:', error);
      });
  } catch (error) {
    console.error('Error in data aggregation middleware:', error);
  }
};
