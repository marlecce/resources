export interface EventPayload {
  [key: string]: unknown;
}

export interface Event {
  id: number;
  name: string;
  payload: EventPayload;
  created_at: Date;
}
