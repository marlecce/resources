import knexInstance from '../../../src/database';
import {
  DEPLOYMENT_TABLENAME,
  DeploymentStatus,
} from '../../../src/models/Deployment';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import * as fetchProjectModule from '../../../src/services/fetch-project';

describe('fetchProjects', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
    {
      id: 4,
      name: 'Project 4',
      url: 'https://project4.com',
      created_at: new Date('2022-04-01'),
      owner_id: 2,
    },
    {
      id: 5,
      name: 'Project 5',
      url: null,
      created_at: new Date('2022-05-01'),
      owner_id: 1,
    },
    {
      id: 6,
      name: 'Project 6',
      url: 'https://project6.com',
      created_at: new Date('2022-06-01'),
      owner_id: 2,
    },
    {
      id: 7,
      name: 'Project 7',
      url: 'https://project7.com',
      created_at: new Date('2022-07-01'),
      owner_id: 1,
    },
    {
      id: 8,
      name: 'Project 8',
      url: null,
      created_at: new Date('2022-08-01'),
      owner_id: 2,
    },
    {
      id: 9,
      name: 'Project 9',
      url: 'https://project9.com',
      created_at: new Date('2022-09-01'),
      owner_id: 1,
    },
    {
      id: 10,
      name: 'Project 10',
      url: 'https://project10.com',
      created_at: new Date('2022-10-01'),
      owner_id: 2,
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
  });

  it('should fetch a project by ID', async () => {
    const projectId = 2;

    const project = await fetchProjectModule.fetchProjectById(projectId);

    expect(project.id).toEqual(mockProjects[1].id);
    expect(project.name).toEqual(mockProjects[1].name);
    expect(project.owner_id).toEqual(mockProjects[1].owner_id);
    expect(project.url).toEqual(mockProjects[1].url);
    expect(project.created_at).toEqual(mockProjects[1].created_at);
    expect(project.hasLiveDeployment).toBeFalsy;
    expect(project.hasOngoingDeployment).toBeFalsy();
  });

  it('should return a project not found error if project id is not found', async () => {
    const projectId = 100;

    await expect(
      fetchProjectModule.fetchProjectById(projectId)
    ).rejects.toThrowError(
      new fetchProjectModule.ProjectNotFoundError(projectId)
    );
  });

  it('should handle errors and propagate them', async () => {
    const projectId = 1;
    const error = new Error('Error fetching project with ID 1');

    jest.spyOn(fetchProjectModule, 'fetchProjectById').mockRejectedValue(error);

    await expect(
      fetchProjectModule.fetchProjectById(projectId)
    ).rejects.toThrowError(error);

    jest.restoreAllMocks();
  });

  it('should set hasOngoingDeployment to true if project has ongoing deployments', async () => {
    const projectId = 3;

    await knexInstance(DEPLOYMENT_TABLENAME).insert({
      project_id: projectId,
      status: DeploymentStatus.Pending,
      created_at: new Date(),
      app_secret: 'test-secret',
    });

    const project = await fetchProjectModule.fetchProjectById(projectId);

    expect(project.hasOngoingDeployment).toBeTruthy();
    expect(project.hasLiveDeployment).toBeFalsy();
  });

  it('should set hasLiveDeployment to true if project has live deployments', async () => {
    const projectId = 4;

    await knexInstance(DEPLOYMENT_TABLENAME).insert({
      project_id: projectId,
      status: DeploymentStatus.Done,
      created_at: new Date(),
      app_secret: 'test-secret',
    });

    const project = await fetchProjectModule.fetchProjectById(projectId);

    expect(project.hasOngoingDeployment).toBeFalsy();
    expect(project.hasLiveDeployment).toBeTruthy();
  });

  it('should set hasOngoingDeployment and hasLiveDeployment to true if project has both ongoing and live deployments', async () => {
    const projectId = 5;

    await knexInstance(DEPLOYMENT_TABLENAME).insert({
      project_id: projectId,
      status: DeploymentStatus.Pending,
      created_at: new Date(),
      app_secret: 'test-secret',
    });

    await knexInstance(DEPLOYMENT_TABLENAME).insert({
      project_id: projectId,
      status: DeploymentStatus.Done,
      created_at: new Date(),
      app_secret: 'test-secret',
    });

    const project = await fetchProjectModule.fetchProjectById(projectId);

    expect(project.hasOngoingDeployment).toBeTruthy();
    expect(project.hasLiveDeployment).toBeTruthy();
  });
});
