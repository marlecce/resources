import knexInstance from '../../src/database';
import { EventPayload } from '../../src/models/Event';

import * as createEventModule from '../../src/service/create-event';

describe('fetchProjects', () => {
  beforeEach(async () => {
    await knexInstance('events').delete();
  });

  afterAll(async () => {
    await knexInstance('events').delete();

    await knexInstance.destroy();
  });

  it('should create a new event', async () => {
    const name = 'Event1';
    const payload: EventPayload = {
      data: {
        message: 'Hello, World!',
        timestamp: new Date(),
        active: true,
      },
    };

    const event = await createEventModule.createEvent(name, payload);

    expect(event).toBeDefined();
    expect(event.id).toBeDefined();
    expect(event.name).toBe(name);

    const eventData = event.payload.data as {
      message: string;
      timestamp: string;
      active: boolean;
    };

    const payloadData = payload.data as {
      message: string;
      timestamp: Date;
      active: boolean;
    };

    expect(eventData.message).toBe(payloadData.message);
    expect(eventData.timestamp).toBe(payloadData.timestamp.toISOString());
    expect(eventData.active).toBe(payloadData.active);
    expect(event.created_at).toBeDefined();

    const createdEvent = await knexInstance('events')
      .where('id', event.id)
      .first();
    expect(createdEvent).toEqual(event);
  });
});
