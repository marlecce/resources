import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('deployments', (table) => {
    table.increments('id').primary();
    table.integer('project_id').unsigned();
    table.integer('deployed_in').unsigned();
    table.string('status').notNullable();
    table.string('app_secret').notNullable();
    table.timestamp('created_at').defaultTo(knex.fn.now());

    table.foreign('project_id').references('projects.id');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('deployments');
}
