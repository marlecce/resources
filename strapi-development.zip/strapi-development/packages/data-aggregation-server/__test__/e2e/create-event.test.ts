import request from 'supertest';
import { constants } from 'http2';
import knexInstance from '../../src/database';
import { EventPayload } from '../../src/models/Event';
import app from '../../src/index';
import { BEARER_TOKEN } from '../../src/middlewares/token-validation';

describe('createEvent', () => {
  beforeEach(async () => {
    await knexInstance('events').delete();
  });

  afterAll(async () => {
    await knexInstance('events').delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should create a new event', async () => {
    const name = 'Event1';
    const payload: EventPayload = {
      data: {
        message: 'Hello, World!',
        timestamp: new Date(),
        active: true,
      },
    };

    const response = await request(app)
      .post('/api/v1/events')
      .send({ name, payload })
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_CREATED);

    expect(response.body.id).toBeDefined();
    expect(response.body.name).toBe(name);

    const payloadData = payload.data as {
      message: string;
      timestamp: Date;
      active: boolean;
    };

    expect(response.body.payload.data.message).toBe(payloadData.message);
    expect(response.body.payload.data.timestamp).toBe(
      payloadData.timestamp.toISOString()
    );
    expect(response.body.payload.data.active).toBe(payloadData.active);
    expect(response.body.created_at).toBeDefined();
  });

  it('should return an error when creating an event with missing name', async () => {
    const payload: EventPayload = {
      data: {
        message: 'Hello, World!',
        timestamp: new Date(),
        active: true,
      },
    };

    const response = await request(app)
      .post('/api/v1/events')
      .send({ payload })
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(constants.HTTP_STATUS_BAD_REQUEST);
    expect(response.body.error).toBe('Event name is required');
  });
});
