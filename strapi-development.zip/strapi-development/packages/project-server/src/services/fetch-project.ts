import { PROJECT_TABLENAME, Project } from '../models/Project';
import knex from '../database';
import { DEPLOYMENT_TABLENAME, DeploymentStatus } from '../models/Deployment';

export class ProjectNotFoundError extends Error {
  constructor(projectId: number) {
    super(`Project with ID ${projectId} not found`);
    this.name = 'ProjectNotFoundError';
  }
}

export async function fetchProjectById(projectId: number): Promise<Project> {
  try {
    const project = await knex<Project>(PROJECT_TABLENAME)
      .select(
        'projects.id',
        'projects.name',
        'projects.url',
        'projects.owner_id',
        'projects.created_at',
        knex.raw(
          `COUNT(DISTINCT CASE WHEN deployments.status IN ('${DeploymentStatus.Pending}', '${DeploymentStatus.Building}', '${DeploymentStatus.Deploying}') THEN deployments.id END) > 0 as has_ongoing_deployment`
        ),
        knex.raw(
          `COUNT(DISTINCT CASE WHEN deployments.status = '${DeploymentStatus.Done}' THEN deployments.id END) > 0 as has_live_deployment`
        )
      )
      .leftJoin(DEPLOYMENT_TABLENAME, 'projects.id', 'deployments.project_id')
      .where('projects.id', projectId)
      .groupBy('projects.id')
      .first();

    if (!project) {
      throw new ProjectNotFoundError(projectId);
    }

    project.hasOngoingDeployment = !!project.has_ongoing_deployment;
    project.hasLiveDeployment = !!project.has_live_deployment;

    delete project.has_ongoing_deployment;
    delete project.has_live_deployment;

    return project;
  } catch (error) {
    console.error(`Error fetching project with ID ${projectId}:`, error);
    throw error;
  }
}
