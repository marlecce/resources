import { PROJECT_TABLENAME, Project } from '../models/Project';
import knex from '../database';
import { calculateOffset, fetchTotalItemCount } from './utils';

export interface FetchProjectsResult {
  projects: Project[];
  page: number;
  pageSize: number;
  totalCount: number;
}

export async function fetchProjects(
  page: number,
  pageSize: number
): Promise<FetchProjectsResult> {
  try {
    const offset = calculateOffset(page, pageSize);

    const [projects, totalCount] = await Promise.all([
      fetchProjectsWithPagination(offset, pageSize),
      fetchTotalItemCount(PROJECT_TABLENAME),
    ]);

    return {
      projects,
      page,
      pageSize,
      totalCount,
    };
  } catch (error) {
    console.error('Error fetching projects:', error);
    throw error;
  }
}

async function fetchProjectsWithPagination(
  offset: number,
  pageSize: number
): Promise<Project[]> {
  return knex<Project>(PROJECT_TABLENAME).offset(offset).limit(pageSize);
}
