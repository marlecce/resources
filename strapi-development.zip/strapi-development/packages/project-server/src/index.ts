import Koa from 'koa';
import Router from 'koa-router';
import bodyParser from 'koa-bodyparser';

import tokenValidationMiddleware from './middlewares/token-validation';

import projectsRoutes from './routes/projects-routes';
import deploymentsRoutes from './routes/deployments-routes';
import { dataAggregationMiddleware } from './middlewares/data-aggregation';

const app = new Koa();

// middlewares
app.use(bodyParser());
app.use(tokenValidationMiddleware);
app.use(dataAggregationMiddleware);

// routes
const v1Router = new Router({ prefix: '/api/v1' });
v1Router.get('/', (ctx) => {
  ctx.body = 'Hello, world!';
});

app.use(v1Router.routes());
v1Router.use('/projects', projectsRoutes.routes());
v1Router.use('/deployments', deploymentsRoutes.routes());

export default app.listen(3000, () => {
  console.log('Project Server running on port 3000');
});
