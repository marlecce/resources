import { DEPLOYMENT_TABLENAME, Deployment } from '../models/Deployment';
import knex from '../database';

export async function createDeployment(
  projectId: number,
  status: Deployment['status'],
  appSecret: string
): Promise<Deployment> {
  try {
    const deployment: Omit<Deployment, 'id'> = {
      project_id: projectId,
      deployed_in: null,
      status,
      app_secret: appSecret,
      created_at: new Date(),
    };

    const [createdDeployment] = await knex<Deployment>(DEPLOYMENT_TABLENAME)
      .insert(deployment)
      .returning('*');

    return createdDeployment;
  } catch (error) {
    console.error(
      `Error creating deployment for project with ID ${projectId}:`,
      error
    );
    throw error;
  }
}
