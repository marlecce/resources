import knexInstance from '../../../src/database';
import {
  DeploymentStatus,
  Deployment,
  DEPLOYMENT_TABLENAME,
} from '../../../src/models/Deployment';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import * as fetchDeploymentModule from '../../../src/services/fetch-deployments';

describe('fetchDeployments', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  const mockDeployments: Deployment[] = [
    {
      id: 1,
      project_id: 1,
      deployed_in: 1,
      status: DeploymentStatus.Done,
      app_secret: 'abc123',
      created_at: new Date('2022-01-01'),
    },
    {
      id: 2,
      project_id: 1,
      deployed_in: 2,
      status: DeploymentStatus.Done,
      app_secret: 'def456',
      created_at: new Date('2022-01-02'),
    },
    {
      id: 3,
      project_id: 2,
      deployed_in: 3,
      status: DeploymentStatus.Done,
      app_secret: 'ghi789',
      created_at: new Date('2022-01-03'),
    },
    {
      id: 4,
      project_id: 2,
      deployed_in: 4,
      status: DeploymentStatus.Done,
      app_secret: 'jkl012',
      created_at: new Date('2022-01-04'),
    },
    {
      id: 5,
      project_id: 3,
      deployed_in: 5,
      status: DeploymentStatus.Done,
      app_secret: 'mno345',
      created_at: new Date('2022-01-05'),
    },
    {
      id: 6,
      project_id: 3,
      deployed_in: 6,
      status: DeploymentStatus.Done,
      app_secret: 'pqr678',
      created_at: new Date('2022-01-06'),
    },
    {
      id: 7,
      project_id: 3,
      deployed_in: 7,
      status: DeploymentStatus.Done,
      app_secret: 'stu901',
      created_at: new Date('2022-01-07'),
    },
    {
      id: 8,
      project_id: 3,
      deployed_in: 8,
      status: DeploymentStatus.Done,
      app_secret: 'vwx234',
      created_at: new Date('2022-01-08'),
    },
    {
      id: 9,
      project_id: 3,
      deployed_in: 9,
      status: DeploymentStatus.Done,
      app_secret: 'yz0123',
      created_at: new Date('2022-01-09'),
    },
    {
      id: 10,
      project_id: 3,
      deployed_in: 10,
      status: DeploymentStatus.Done,
      app_secret: '456789',
      created_at: new Date('2022-01-10'),
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
    await knexInstance(DEPLOYMENT_TABLENAME).insert(mockDeployments);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
  });

  it('should fetch deployments successfully', async () => {
    const page = 1;
    const pageSize = 8;
    const result = await fetchDeploymentModule.fetchDeployments(page, pageSize);

    expect(result.page).toEqual(page);
    expect(result.pageSize).toEqual(pageSize);
    expect(result.deployments.length).toEqual(pageSize);
    expect(result.totalCount).toEqual(mockDeployments.length);
  });

  it('should fetch deployments with correct pagination', async () => {
    const page = 2;
    const pageSize = 5;
    const expectedDeployments = mockDeployments.slice(
      (page - 1) * pageSize,
      page * pageSize
    );

    const result = await fetchDeploymentModule.fetchDeployments(page, pageSize);

    expect(result.page).toEqual(page);
    expect(result.pageSize).toEqual(pageSize);
    expect(result.deployments.length).toEqual(expectedDeployments.length);
    expect(result.totalCount).toEqual(mockDeployments.length);

    for (let i = 0; i < expectedDeployments.length; i++) {
      expect(result.deployments[i].id).toEqual(expectedDeployments[i].id);
      expect(result.deployments[i].deployed_in).toEqual(
        expectedDeployments[i].deployed_in
      );
    }
  });

  it('should return an empty deployments array when no deployments exist', async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();

    const page = 1;
    const pageSize = 10;

    const result = await fetchDeploymentModule.fetchDeployments(page, pageSize);

    expect(result.page).toEqual(page);
    expect(result.pageSize).toEqual(pageSize);
    expect(result.deployments.length).toEqual(0);
    expect(result.totalCount).toEqual(0);
  });

  it('should handle errors and re-throw them', async () => {
    const errorMessage = 'A non-negative integer must be provided to offset.';

    const page = -1;
    const pageSize = 10;

    await expect(
      fetchDeploymentModule.fetchDeployments(page, pageSize)
    ).rejects.toThrowError(errorMessage);
  });
});
