import { Knex } from 'knex';

export async function up(knex: Knex): Promise<void> {
  await knex.schema.createTable('projects', (table) => {
    table.increments('id').primary();
    table.string('name').notNullable();
    table.string('url');
    table.timestamp('created_at').defaultTo(knex.fn.now());
    table
      .integer('owner_id')
      .unsigned()
      .notNullable()
      .references('users.id')
      .onDelete('CASCADE');
  });
}

export async function down(knex: Knex): Promise<void> {
  await knex.schema.dropTable('projects');
}
