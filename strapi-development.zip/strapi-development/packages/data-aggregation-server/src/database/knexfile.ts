import { Knex } from 'knex';

interface KnexConfiguration {
  development: Knex.Config;
}

const knexfile: KnexConfiguration = {
  development: {
    client: 'pg',
    connection: {
      host: 'localhost',
      port: 5432,
      database: 'strapi_devel',
      user: 'devel',
      password: 'devel',
    },
  },
};

export default knexfile;
