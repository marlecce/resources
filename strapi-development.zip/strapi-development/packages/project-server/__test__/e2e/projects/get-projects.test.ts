import request from 'supertest';

import knexInstance from '../../../src/database';
import app from '../../../src/index';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import { BEARER_TOKEN } from '../../../src/middlewares/token-validation';

describe('/projects endpoint', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
    {
      id: 4,
      name: 'Project 4',
      url: 'https://project4.com',
      created_at: new Date('2022-04-01'),
      owner_id: 2,
    },
    {
      id: 5,
      name: 'Project 5',
      url: null,
      created_at: new Date('2022-05-01'),
      owner_id: 1,
    },
    {
      id: 6,
      name: 'Project 6',
      url: 'https://project6.com',
      created_at: new Date('2022-06-01'),
      owner_id: 2,
    },
    {
      id: 7,
      name: 'Project 7',
      url: 'https://project7.com',
      created_at: new Date('2022-07-01'),
      owner_id: 1,
    },
    {
      id: 8,
      name: 'Project 8',
      url: null,
      created_at: new Date('2022-08-01'),
      owner_id: 2,
    },
    {
      id: 9,
      name: 'Project 9',
      url: 'https://project9.com',
      created_at: new Date('2022-09-01'),
      owner_id: 1,
    },
    {
      id: 10,
      name: 'Project 10',
      url: 'https://project10.com',
      created_at: new Date('2022-10-01'),
      owner_id: 2,
    },
  ];

  beforeEach(async () => {
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
  });

  afterAll(async () => {
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should return a paginated list of projects', async () => {
    const pageSize = 8;
    const response = await request(app)
      .get('/api/v1/projects')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty(PROJECT_TABLENAME);
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('pageSize');
    expect(response.body).toHaveProperty('totalCount');

    const projectsInResponse = response.body.projects;
    const projectsInDatabase = await knexInstance<Project>(PROJECT_TABLENAME)
      .select()
      .limit(pageSize);

    const projectsInDatabaseFormatted = projectsInDatabase.map((project) => ({
      ...project,
      created_at: project.created_at.toISOString(),
    }));

    expect(projectsInResponse.length).toBe(pageSize);
    expect(projectsInResponse).toEqual(projectsInDatabaseFormatted);
  });

  it('should return the projects with the specified page size', async () => {
    const pageSize = 8;
    const response = await request(app)
      .get('/api/v1/projects')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.body.projects.length).toBe(pageSize);

    const projectsInResponse = response.body.projects;
    const expectedProjects = mockProjects.slice(0, pageSize);

    const expectedProjectsFormatted = expectedProjects.map((project) => ({
      ...project,
      created_at: project.created_at.toISOString(),
    }));

    expect(projectsInResponse).toEqual(expectedProjectsFormatted);
  });

  it('should return the projects for the specified page', async () => {
    const page = 2;
    const response = await request(app)
      .get('/api/v1/projects?page=2')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.body.page).toBe(page);

    const project9 = response.body.projects[0];
    const project10 = response.body.projects[1];

    const mockProjectsFormatted = [
      ...mockProjects.slice(0, 8),
      {
        ...mockProjects[8],
        created_at: mockProjects[8].created_at.toISOString(),
      },
      {
        ...mockProjects[9],
        created_at: mockProjects[9].created_at.toISOString(),
      },
    ];

    expect(project9).toEqual(mockProjectsFormatted[8]);
    expect(project10).toEqual(mockProjectsFormatted[9]);
  });

  it('should handle errors and return a 500 status code', async () => {
    const response = await request(app)
      .get('/api/v1/projects?page=-1')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`);

    expect(response.status).toBe(500);
    expect(response.body).toEqual({
      error: 'An error occurred while retrieving projects',
    });
  });
});
