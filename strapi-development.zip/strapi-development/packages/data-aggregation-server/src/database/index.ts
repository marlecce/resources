import knexfile from './knexfile';
import Knex from 'knex';

const knexInstance = Knex(knexfile.development);
export default knexInstance;
