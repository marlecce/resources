export const PROJECT_TABLENAME = 'projects';

export interface Project {
  id: number;
  name: string;
  url?: string | null;
  created_at: Date;
  owner_id: number;
  hasOngoingDeployment?: boolean;
  hasLiveDeployment?: boolean;
}
