import knexInstance from '../database';
import { DEPLOYMENT_TABLENAME } from '../models/Deployment';
import { PROJECT_TABLENAME, Project } from '../models/Project';

export async function isFirstProjectDeployment(
  projectId: number
): Promise<boolean> {
  try {
    const [{ count }] = await knexInstance(DEPLOYMENT_TABLENAME)
      .where({ project_id: projectId })
      .count('id as count');

    return Number(count) === 1;
  } catch (error) {
    console.error('Error checking first project deployment:', error);
    throw new Error(
      'An error occurred while checking first project deployment'
    );
  }
}

export async function updateProjectUrl(
  projectId: number,
  url: string
): Promise<void> {
  try {
    const updatedRows = await knexInstance<Project>(PROJECT_TABLENAME)
      .where({ id: projectId })
      .update({ url });

    if (updatedRows === 0) {
      throw new Error('Project update failed');
    }
  } catch (error) {
    console.error(
      `Error updating project URL for project ID ${projectId}:`,
      error
    );
    throw new Error('An error occurred while updating project URL');
  }
}

export function generateRandomUrl(): string {
  const characters =
    'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const length = 10;
  let randomUrl = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    randomUrl += characters[randomIndex];
  }

  return randomUrl;
}

export function calculateOffset(page: number, pageSize: number): number {
  return (page - 1) * pageSize;
}

export async function fetchTotalItemCount(tableName: string): Promise<number> {
  const [{ total }] = await knexInstance(tableName).count('id as total');
  return Number(total) || 0;
}
