# Strapi Monorepo

This monorepo contains multiple services for the Strapi project:

- migration services
- project server
- data aggregation server

Read the [Write up](write_up.md) document for explanations about my choices and how I worked.

## Prerequisites

| To install     | Recommended Version |
| -------------- | ------------------- |
| Node.js        | v18.12.1            |
| npm            | 9.2.0               |
| Yarn           | 3.4.1               |
| Docker         | 23.0.5              |
| Docker Compose | v2.17.3             |
|                |                     |

## Installation

- unzip the repo
- Change to the project's root directory:

```bash
cd strapi-development
```

- Install the dependencies for all the packages:

```bash
yarn install
```

- Startup the database container:

```bash
docker compose up -d
```

- Setup tha database and run the seed (optional)

```bash
cd packages/migrations
yarn knex migrate:latest
# optional
yarn knex seed:run
```

## Testing

To verify that the installation was successful, you can run the server tests.

To run the tests for the Project Server, execute the following command in the project's root directory:

```bash
cd packages/project-server
yarn test
```

To run the tests for the Data Aggregation Server, execute the following command:

```bash
cd packages/data-aggregation-server
yarn test
```

## Project server:

To run the Project server:

```bash
cd packages/project-server
yarn start
```

## Data Aggragation server:

To run the Data Aggragation server:

```bash
cd packages/data-aggregation-server
yarn start
```
