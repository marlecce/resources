import Koa from 'koa';
import Router from 'koa-router';
import bodyParser from 'koa-bodyparser';

import tokenValidationMiddleware from './middlewares/token-validation';

import routes from './routes';

const app = new Koa();
const port = 3001;

// middlewares
app.use(bodyParser());
app.use(tokenValidationMiddleware);

// routes
const v1Router = new Router({ prefix: '/api/v1' });
v1Router.get('/', (ctx) => {
  ctx.body = 'Hello, world!';
});

app.use(v1Router.routes());
v1Router.use('/events', routes.routes());

export default app.listen(port, () => {
  console.log(`Data aggregation Server running on port ${port}`);
});
