import request from 'supertest';
import axios from 'axios';
import { constants } from 'http2';

import app from '../../src/index';
import knexInstance from '../../src/database';
import { BEARER_TOKEN } from '../../src/middlewares/token-validation';
import {
  DEPLOYMENT_TABLENAME,
  Deployment,
  DeploymentStatus,
} from '../../src/models/Deployment';
import { PROJECT_TABLENAME, Project } from '../../src/models/Project';

jest.mock('axios');

const mockedAxios = axios as jest.Mocked<typeof axios>;

const mockDataAggregatorResponse = {
  status: constants.HTTP_STATUS_OK,
};

describe('Data Aggregation Middleware', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  const mockDeployments: Deployment[] = [
    {
      id: 1,
      project_id: 1,
      deployed_in: 1,
      status: DeploymentStatus.Done,
      app_secret: 'abc123',
      created_at: new Date('2022-01-01'),
    },
    {
      id: 2,
      project_id: 1,
      deployed_in: 2,
      status: DeploymentStatus.Done,
      app_secret: 'def456',
      created_at: new Date('2022-01-02'),
    },
  ];

  beforeEach(async () => {
    await knexInstance('events').delete();
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
    await knexInstance(DEPLOYMENT_TABLENAME).insert(mockDeployments);
    mockedAxios.post.mockClear();
  });

  afterAll(async () => {
    await knexInstance('events').delete();
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should send event to Data Aggregator service for a GET request', async () => {
    mockedAxios.post.mockResolvedValueOnce(mockDataAggregatorResponse);

    await request(app)
      .get('/api/v1/')
      .set('Authorization', `Bearer ${BEARER_TOKEN}`)
      .expect(constants.HTTP_STATUS_OK);

    expect(mockedAxios.post).toHaveBeenCalledTimes(1);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      'http://localhost:3001/api/v1/events',
      {
        name: 'operation',
        payload: {
          method: 'GET',
          path: '/api/v1/',
          request: { body: {}, params: {}, query: {} },
          response: { body: 'Hello, world!', status: 200 },
        },
      },
      {
        headers: { Authorization: 'Bearer your-bearer-token-data-aggregation' },
      }
    );
  });

  it('should send event to Data Aggregator service for a POST request', async () => {
    mockedAxios.post.mockResolvedValueOnce(mockDataAggregatorResponse);

    const projectId = 1;
    const validRequestBody = {
      status: DeploymentStatus.Pending,
      appSecret: 'test-secret',
    };

    await request(app)
      .post(`/api/v1/projects/${projectId}/deployments`)
      .send(validRequestBody)
      .set('Authorization', `Bearer ${BEARER_TOKEN}`)
      .expect(constants.HTTP_STATUS_CREATED);

    expect(mockedAxios.post).toHaveBeenCalledTimes(1);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      'http://localhost:3001/api/v1/events',
      {
        name: 'operation',
        payload: {
          method: 'POST',
          path: '/api/v1/projects/1/deployments',
          request: {
            body: {
              appSecret: 'test-secret',
              status: 'pending',
            },
            params: { id: '1' },
            query: {},
          },
          response: {
            body: {
              app_secret: 'test-secret',
              created_at: expect.any(Date),
              deployed_in: null,
              id: expect.any(Number),
              project_id: 1,
              status: 'pending',
            },
            status: constants.HTTP_STATUS_CREATED,
          },
        },
      },
      {
        headers: { Authorization: 'Bearer your-bearer-token-data-aggregation' },
      }
    );
  });

  it('should send event to Data Aggregator service for a DELETE request', async () => {
    mockedAxios.post.mockResolvedValueOnce(mockDataAggregatorResponse);

    const deploymentId = 1;

    await request(app)
      .delete(`/api/v1/deployments/${deploymentId}`)
      .set('Authorization', `Bearer ${BEARER_TOKEN}`)
      .expect(constants.HTTP_STATUS_NO_CONTENT);

    expect(mockedAxios.post).toHaveBeenCalledTimes(1);
    expect(mockedAxios.post).toHaveBeenCalledWith(
      'http://localhost:3001/api/v1/events',
      {
        name: 'operation',
        payload: {
          method: 'DELETE',
          path: `/api/v1/deployments/${deploymentId}`,
          request: {
            body: {},
            params: { id: '1' },
            query: {},
          },
          response: {
            status: constants.HTTP_STATUS_NO_CONTENT,
          },
        },
      },
      {
        headers: { Authorization: 'Bearer your-bearer-token-data-aggregation' },
      }
    );
  });
});
