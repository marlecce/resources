import Router from 'koa-router';
import { constants } from 'http2';

import { EventPayload } from '../models/Event';
import { createEvent } from '../service/create-event';

const router = new Router();

router.post('/', async (ctx) => {
  const { name, payload }: { name: string; payload: EventPayload } = ctx.request
    .body as {
    name: string;
    payload: EventPayload;
  };

  if (!name) {
    ctx.status = constants.HTTP_STATUS_BAD_REQUEST;
    ctx.body = { error: 'Event name is required' };
    return;
  }

  try {
    const createdEvent = await createEvent(name, payload);
    ctx.status = constants.HTTP_STATUS_CREATED;
    ctx.body = createdEvent;
  } catch (error) {
    console.error('Error saving event:', error);

    ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
    ctx.body = { error: 'Failed to create event' };
  }
});

export default router;
