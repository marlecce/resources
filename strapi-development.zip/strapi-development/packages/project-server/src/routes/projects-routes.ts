import Koa from 'koa';
import Router from 'koa-router';
import { constants } from 'http2';

import { fetchProjects, FetchProjectsResult } from '../services/fetch-projects';
import {
  fetchProjectById,
  ProjectNotFoundError,
} from '../services/fetch-project';
import { createDeployment } from '../services/create-deployment';
import { DeploymentStatus } from '../models/Deployment';

const router = new Router();

router.get('/', async (ctx: Koa.Context) => {
  try {
    const page = ctx.query.page ? parseInt(ctx.query.page as string, 10) : 1;
    const pageSize = 8;

    const result: FetchProjectsResult = await fetchProjects(page, pageSize);

    ctx.body = result;
  } catch (error) {
    console.error('Error retrieving projects:', error);
    ctx.status = 500;
    ctx.body = { error: 'An error occurred while retrieving projects' };
  }
});

router.get('/:id', async (ctx: Koa.Context) => {
  try {
    const projectId = parseInt(ctx.params.id as string, 10);

    const project = await fetchProjectById(projectId);

    ctx.body = project;
  } catch (error) {
    console.error('Error retrieving project:', error);

    if (error instanceof ProjectNotFoundError) {
      ctx.status = constants.HTTP_STATUS_NOT_FOUND;
      ctx.body = { error: 'Project not found' };
    } else {
      ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
      ctx.body = { error: 'An error occurred while retrieving the project' };
    }
  }
});

router.post('/:id/deployments', async (ctx: Koa.Context) => {
  try {
    const projectId = parseInt(ctx.params.id as string, 10);

    const { status, appSecret } = ctx.request.body as {
      status: DeploymentStatus;
      appSecret: string;
    };

    const deployment = await createDeployment(projectId, status, appSecret);

    ctx.body = deployment;
    ctx.status = constants.HTTP_STATUS_CREATED;
  } catch (error) {
    console.error('Error creating deployment:', error);
    ctx.status = constants.HTTP_STATUS_INTERNAL_SERVER_ERROR;
    ctx.body = { error: 'An error occurred while creating the deployment' };
  }
});

export default router;
