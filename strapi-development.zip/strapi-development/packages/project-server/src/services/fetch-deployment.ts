import { DEPLOYMENT_TABLENAME, Deployment } from '../models/Deployment';
import knex from '../database';

export class DeploymentNotFoundError extends Error {
  constructor(deploymentId: number) {
    super(`Deployment with ID ${deploymentId} not found`);
    this.name = 'DeploymentNotFoundError';
  }
}

export async function fetchDeploymentById(
  deploymentId: number
): Promise<Deployment> {
  try {
    const deployment = await knex<Deployment>(DEPLOYMENT_TABLENAME)
      .where('id', deploymentId)
      .first();

    if (!deployment) {
      throw new DeploymentNotFoundError(deploymentId);
    }

    return deployment;
  } catch (error) {
    console.error(`Error fetching deployment with ID ${deploymentId}:`, error);
    throw error;
  }
}
