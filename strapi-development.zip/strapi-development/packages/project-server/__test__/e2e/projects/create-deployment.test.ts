import request from 'supertest';
import { constants } from 'http2';

import knexInstance from '../../../src/database';
import app from '../../../src/index';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import {
  DEPLOYMENT_TABLENAME,
  DeploymentStatus,
} from '../../../src/models/Deployment';
import { BEARER_TOKEN } from '../../../src/middlewares/token-validation';

describe('/projects deployment endpoint', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
  ];

  beforeEach(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();

    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
  });

  afterAll(async () => {
    await knexInstance(DEPLOYMENT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
    app.close();
  });

  it('should return unauthorized status if no auth token is passed', async () => {
    const projectId = 1;
    const validRequestBody = {
      status: DeploymentStatus.Pending,
      appSecret: 'test-secret',
    };

    await request(app)
      .post(`/api/v1/projects/${projectId}/deployments`)
      .send(validRequestBody)
      .expect(constants.HTTP_STATUS_UNAUTHORIZED);
  });

  it('should create a new deployment and return 201 status', async () => {
    const projectId = 1;
    const validRequestBody = {
      status: DeploymentStatus.Pending,
      appSecret: 'test-secret',
    };

    const response = await request(app)
      .post(`/api/v1/projects/${projectId}/deployments`)
      .send(validRequestBody)
      .set('Authorization', `Bearer ${BEARER_TOKEN}`)
      .expect(constants.HTTP_STATUS_CREATED);

    expect(response.body).toBeDefined();
    expect(response.body.id).toBeDefined();
    expect(response.body.project_id).toBe(projectId);
    expect(response.body.status).toBe(validRequestBody.status);
    expect(response.body.app_secret).toBe(validRequestBody.appSecret);
    expect(response.body.created_at).toBeDefined();

    const createdDeployment = await knexInstance(DEPLOYMENT_TABLENAME)
      .where('id', response.body.id)
      .first();

    expect(createdDeployment).toBeDefined();
    expect(createdDeployment.project_id).toBe(projectId);
    expect(createdDeployment.status).toBe(validRequestBody.status);
    expect(createdDeployment.app_secret).toBe(validRequestBody.appSecret);
    expect(createdDeployment.created_at).toBeDefined();
  });

  it('return an internal server error for a non-existent project ID ', async () => {
    const projectId = 9999;
    const validRequestBody = {
      status: DeploymentStatus.Pending,
      appSecret: 'test-secret',
    };

    await request(app)
      .post(`/api/v1/projects/${projectId}/deployments`)
      .send(validRequestBody)
      .set('Authorization', `Bearer ${BEARER_TOKEN}`)
      .expect(constants.HTTP_STATUS_INTERNAL_SERVER_ERROR);
  });
});
