import knexInstance from '../../../src/database';
import { PROJECT_TABLENAME, Project } from '../../../src/models/Project';
import { fetchProjects } from '../../../src/services/fetch-projects';

describe('fetchProjects', () => {
  const mockProjects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      url: 'https://project1.com',
      created_at: new Date('2022-01-01'),
      owner_id: 1,
    },
    {
      id: 2,
      name: 'Project 2',
      url: null,
      created_at: new Date('2022-02-01'),
      owner_id: 2,
    },
    {
      id: 3,
      name: 'Project 3',
      url: 'https://project3.com',
      created_at: new Date('2022-03-01'),
      owner_id: 1,
    },
    {
      id: 4,
      name: 'Project 4',
      url: 'https://project4.com',
      created_at: new Date('2022-04-01'),
      owner_id: 2,
    },
    {
      id: 5,
      name: 'Project 5',
      url: null,
      created_at: new Date('2022-05-01'),
      owner_id: 1,
    },
    {
      id: 6,
      name: 'Project 6',
      url: 'https://project6.com',
      created_at: new Date('2022-06-01'),
      owner_id: 2,
    },
    {
      id: 7,
      name: 'Project 7',
      url: 'https://project7.com',
      created_at: new Date('2022-07-01'),
      owner_id: 1,
    },
    {
      id: 8,
      name: 'Project 8',
      url: null,
      created_at: new Date('2022-08-01'),
      owner_id: 2,
    },
    {
      id: 9,
      name: 'Project 9',
      url: 'https://project9.com',
      created_at: new Date('2022-09-01'),
      owner_id: 1,
    },
    {
      id: 10,
      name: 'Project 10',
      url: 'https://project10.com',
      created_at: new Date('2022-10-01'),
      owner_id: 2,
    },
  ];

  beforeEach(async () => {
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance(PROJECT_TABLENAME).insert(mockProjects);
  });

  afterAll(async () => {
    await knexInstance(PROJECT_TABLENAME).delete();
    await knexInstance.destroy();
  });

  it('should fetch projects successfully', async () => {
    const page = 1;
    const pageSize = 8;
    const result = await fetchProjects(page, pageSize);

    expect(result.page).toEqual(page);
    expect(result.pageSize).toEqual(pageSize);
    expect(result.projects.length).toEqual(pageSize);
    expect(result.totalCount).toEqual(mockProjects.length);

    expect(result.projects[0].id).toEqual(1);
    expect(result.projects[1].id).toEqual(2);
    expect(result.projects[2].id).toEqual(3);

    expect(result.projects[0].name).toEqual(mockProjects[0].name);
    expect(result.projects[1].name).toEqual(mockProjects[1].name);
    expect(result.projects[2].name).toEqual(mockProjects[2].name);
  });

  it('should fetch projects with correct pagination', async () => {
    const page = 2;
    const pageSize = 5;
    const expectedProjects = mockProjects.slice(
      (page - 1) * pageSize,
      page * pageSize
    );

    const result = await fetchProjects(page, pageSize);

    expect(result.page).toEqual(page);
    expect(result.pageSize).toEqual(pageSize);
    expect(result.projects.length).toEqual(expectedProjects.length);
    expect(result.totalCount).toEqual(mockProjects.length);

    for (let i = 0; i < expectedProjects.length; i++) {
      expect(result.projects[i].id).toEqual(expectedProjects[i].id);
      expect(result.projects[i].name).toEqual(expectedProjects[i].name);
    }
  });

  it('should return an empty projects array when no projects exist', async () => {
    await knexInstance(PROJECT_TABLENAME).delete();

    const page = 1;
    const pageSize = 10;

    const result = await fetchProjects(page, pageSize);

    expect(result.page).toEqual(page);
    expect(result.pageSize).toEqual(pageSize);
    expect(result.projects.length).toEqual(0);
    expect(result.totalCount).toEqual(0);
  });

  it('should handle errors and re-throw them', async () => {
    const errorMessage = 'A non-negative integer must be provided to offset.';

    const page = -1;
    const pageSize = 10;

    await expect(fetchProjects(page, pageSize)).rejects.toThrowError(
      errorMessage
    );
  });
});
